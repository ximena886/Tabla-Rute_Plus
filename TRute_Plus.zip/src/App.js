import React from "react";
import "./styles.css";

export default function App() {
  return (
    <div className="App">
      <h1>Integrantes de Rute Plus</h1>

      <table class="egt" className="tabla">
        <tr className="b">
          <th className="b">Nombres</th>

          <th className="b">Apellidos</th>

          <th className="b">Correo</th>

          <th className="b">Celular</th>
        </tr>

        <tr className="b">
          <td className="b">Ximena</td>

          <td className="b">Sanchez Agudelo</td>

          <td className="b">xisanchez@josegalan.edu.co</td>

          <td className="b">3006831848</td>
        </tr>

        <tr className="b">
          <td className="b">Zharik</td>

          <td className="b">Sierra Velez</td>

          <td className="b">zsierra@josegalan.edu.co</td>

          <td className="b">3014233503</td>
        </tr>

        <tr className="b">
          <td className="b">Andres Felipe</td>

          <td className="b">Carvajal Llanos</td>

          <td className="b">null</td>

          <td className="b">3148897895</td>

          <td></td>
        </tr>

        <tr className="b">
          <td className="b">Ferney</td>

          <td className="b">Urrutia Mena</td>

          <td className="b">null</td>

          <td className="b">3023672259</td>
        </tr>
      </table>
    </div>
  );
}
